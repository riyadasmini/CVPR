### Step 1: Mount Google Drive (to access dataset and model files)
from google.colab import drive
import os

drive.mount('/content/drive')
base_dir = '/content/drive/MyDrive/face_detection_project/'  # Update with your directory structure

# Ensure the required directories exist
os.makedirs(base_dir, exist_ok=True)

### Step 2: Import Necessary Libraries
import cv2 as cv
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

### Step 3: Load Haar Cascade for Face Detection
haar_cascade_path = os.path.join(base_dir, 'harr_face.xml')
haarCascade = cv.CascadeClassifier(haar_cascade_path)

### Step 4: Prepare Dataset
DIR = os.path.join(base_dir, 'data/train')
people = ['moynul', 'riya', 'rohan']
features = []
labels = []

def create_training_data():
    for person in people:
        path = os.path.join(DIR, person)
        label = people.index(person)
        for img in os.listdir(path):
            img_path = os.path.join(path, img)
            img_array = cv.imread(img_path)
            gray = cv.cvtColor(img_array, cv.COLOR_BGR2GRAY)
            faces_rect = haarCascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)
            for (x, y, w, h) in faces_rect:
                faces_roi = gray[y:y + h, x:x + w]
                resized_face = cv.resize(faces_roi, (224, 224))
                features.append(resized_face)
                labels.append(label)

create_training_data()
features = np.array(features, dtype='float32') / 255.0  # Normalize
labels = np.array(labels)
features = features.reshape(-1, 224, 224, 1)
X_train, X_val, y_train, y_val = train_test_split(features, labels, test_size=0.2, random_state=42)

### Step 5: Apply Transfer Learning (MobileNetV2)
base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
for layer in base_model.layers:
    layer.trainable = False
x = GlobalAveragePooling2D()(base_model.output)
x = Dense(128, activation='relu')(x)
output_layer = Dense(len(people), activation='softmax')(x)
model = Model(inputs=base_model.input, outputs=output_layer)

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=10, batch_size=16)
model.save(os.path.join(base_dir, 'face_recognition_model.h5'))

### Step 6: Run Face Detection using Webcam
model = tf.keras.models.load_model(os.path.join(base_dir, 'face_recognition_model.h5'))
cap = cv.VideoCapture(0)
while True:
    ret, frame = cap.read()
    if not ret:
        break
    gray = cv.cvtColor(frame, cv.COLOR_BGR2GRAY)
    faces_rect = haarCascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4)
    for (x, y, w, h) in faces_rect:
        face_roi = gray[y:y + h, x:x + w]
        resized_face = cv.resize(face_roi, (224, 224)) / 255.0
        reshaped_face = resized_face.reshape(1, 224, 224, 1)
        predictions = model.predict(reshaped_face)
        label = np.argmax(predictions)
        label_text = f'{people[label]}'
        cv.putText(frame, label_text, (x, y - 10), cv.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv.imshow("Face Detection", frame)
    if cv.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv.destroyAllWindows()
